"""
E-commerce scraper example — targets books.toscrape.com (a safe, scraping-friendly demo site).
Scrapes product listings across multiple pages and exports to both CSV and JSON.

Target: https://books.toscrape.com (no login required, scraping-friendly)
"""

import sys
import os
from pathlib import Path
from dataclasses import dataclass, asdict

# Allow imports from the parent directory
sys.path.insert(0, str(Path(__file__).parent.parent))

from playwright.sync_api import sync_playwright, Page
from export_data import export_csv, export_json
from ui import banner, section, ok, info, warn, err, kv, result_box, done, Spinner, step, progress_bar

BASE_URL   = "https://books.toscrape.com/catalogue/"
OUTPUT_DIR = Path(os.getenv("OUTPUT_DIR", "output"))
OUTPUT_DIR.mkdir(exist_ok=True)

RATING_MAP = {"One": 1, "Two": 2, "Three": 3, "Four": 4, "Five": 5}


@dataclass
class Book:
    title: str
    price: float
    rating: int
    availability: str
    url: str


def parse_books(page: Page) -> list[Book]:
    """Extract all book cards visible on the current catalog page."""
    cards = page.query_selector_all("article.product_pod")
    books: list[Book] = []

    for card in cards:
        title_el = card.query_selector("h3 > a")
        price_el = card.query_selector("p.price_color")
        rating_el = card.query_selector("p.star-rating")
        avail_el  = card.query_selector("p.availability")

        if not all([title_el, price_el, rating_el]):
            continue

        title        = title_el.get_attribute("title") or title_el.inner_text()
        href         = title_el.get_attribute("href") or ""
        price_text   = price_el.inner_text().replace("Â", "").replace("£", "").strip()
        rating_class = rating_el.get_attribute("class") or ""
        rating_word  = rating_class.replace("star-rating", "").strip()
        availability = avail_el.inner_text().strip() if avail_el else "Unknown"

        books.append(Book(
            title=title,
            price=float(price_text),
            rating=RATING_MAP.get(rating_word, 0),
            availability=availability,
            url=BASE_URL + href.replace("../", ""),
        ))

    return books


def scrape_catalogue(max_pages: int = 3, headless: bool = True) -> list[Book]:
    """
    Scrape the books.toscrape.com catalogue across multiple paginated pages.
    Set max_pages=50 to scrape the entire site (1000 books).
    """
    all_books: list[Book] = []

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=headless)
        context = browser.new_context(viewport={"width": 1280, "height": 900})
        page    = context.new_page()

        for page_num in range(1, max_pages + 1):
            url = f"{BASE_URL}page-{page_num}.html"
            step(page_num, max_pages, f"Scraping page {page_num}")

            try:
                with Spinner(f"Loading page {page_num}"):
                    page.goto(url, wait_until="networkidle", timeout=15_000)
                    page.wait_for_selector("article.product_pod", timeout=10_000)
            except Exception as e:
                err(f"Could not load page {page_num}: {e}")
                break

            books = parse_books(page)
            all_books.extend(books)
            ok(f"Found {len(books)} books  (total: {len(all_books)})")
            progress_bar(page_num, max_pages, f"pages scraped")

            # Stop if there's no "next" button (last page)
            if not page.query_selector("li.next"):
                ok("Reached last page.")
                break

        browser.close()

    return all_books


def main() -> None:
    banner("E-commerce Scraper", "books.toscrape.com — paginated product scraping")

    section("Scraping catalogue")
    books = scrape_catalogue(max_pages=3)

    if not books:
        err("No books scraped. Check your connection.")
        return

    section("Exporting data")
    records  = [asdict(b) for b in books]
    csv_path  = export_csv(records, "books.csv")
    json_path = export_json(records, "books.json")

    # Quick stats
    avg_price  = sum(b.price  for b in books) / len(books)
    avg_rating = sum(b.rating for b in books) / len(books)
    stars      = "★" * round(avg_rating) + "☆" * (5 - round(avg_rating))

    result_box([
        ("Total books",  str(len(books))),
        ("Avg price",    f"£{avg_price:.2f}"),
        ("Avg rating",   f"{avg_rating:.1f} / 5  {stars}"),
        ("CSV output",   str(csv_path)),
        ("JSON output",  str(json_path)),
    ], title="Scrape Summary")

    done(f"Scraped {len(books)} books successfully.")


if __name__ == "__main__":
    main()
