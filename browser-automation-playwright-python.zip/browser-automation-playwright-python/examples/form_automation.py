"""
Form automation example — fills and submits various HTML form types.
Targets https://demoqa.com/automation-practice-form (a public practice form).

Demonstrates: text inputs, dropdowns, radio buttons, checkboxes, date pickers,
file uploads, and reading the confirmation modal after submission.
"""

import sys
import os
from pathlib import Path
from dataclasses import dataclass, asdict
from datetime import datetime

sys.path.insert(0, str(Path(__file__).parent.parent))

from playwright.sync_api import sync_playwright, Page, TimeoutError as PWTimeoutError
from export_data import export_json
from ui import banner, section, ok, info, warn, kv, result_box, done, Spinner, step

OUTPUT_DIR = Path(os.getenv("OUTPUT_DIR", "output"))
OUTPUT_DIR.mkdir(exist_ok=True)


@dataclass
class FormSubmissionResult:
    submitted_at: str
    name: str
    email: str
    gender: str
    mobile: str
    subjects: list[str]
    hobbies: list[str]
    address: str
    state: str
    city: str
    confirmation_text: str
    screenshot: str


def _ordinal(n: int) -> str:
    """Return ordinal string for a day number, e.g. 15 -> '15th'."""
    if 11 <= (n % 100) <= 13:
        return f"{n}th"
    return f"{n}" + {1: "st", 2: "nd", 3: "rd"}.get(n % 10, "th")


def _set_date_picker(page: Page, day: str, month: str, year: str) -> None:
    """
    Set the react-datepicker via its month/year dropdowns and day click.
    day/month/year are strings, e.g. '15', 'March', '1995'.
    The aria-label format is: 'Choose <weekday>, <Month> <day ordinal>, <year>'
    """
    page.click("#dateOfBirthInput")
    page.wait_for_selector(".react-datepicker", timeout=5_000)

    # Select month and year from the header dropdowns
    page.select_option(".react-datepicker__month-select", label=month)
    page.select_option(".react-datepicker__year-select", value=year)
    page.wait_for_timeout(300)

    # Build the ordinal day string used in aria-label (e.g. "15th")
    day_ordinal = _ordinal(int(day))

    # Click the day cell matching month+ordinal day+year — excludes outside-month cells
    page.click(
        f".react-datepicker__day:not(.react-datepicker__day--outside-month)"
        f"[aria-label*='{month} {day_ordinal}, {year}']"
    )


def fill_practice_form(page: Page, data: dict) -> str:
    """
    Fill every field in the DemoQA practice form and submit it.
    Returns the confirmation modal text.
    """
    page.goto("https://demoqa.com/automation-practice-form", wait_until="networkidle")

    # Remove sticky ad banner and footer that overlap form elements
    page.evaluate("document.getElementById('fixedban')?.remove()")
    page.evaluate("document.querySelector('footer')?.remove()")

    # --- Basic text fields ---
    page.fill("#firstName", data["first_name"])
    page.fill("#lastName",  data["last_name"])
    page.fill("#userEmail", data["email"])
    page.fill("#userNumber", data["mobile"])

    # --- Gender radio ---
    page.click(f"label[for='gender-radio-{data['gender_index']}']")

    # --- Date of birth via calendar widget ---
    _set_date_picker(page, data["dob_day"], data["dob_month"], data["dob_year"])

    # --- Subjects autocomplete ---
    for subject in data.get("subjects", []):
        page.fill("#subjectsInput", subject)
        page.wait_for_selector(".subjects-auto-complete__option", timeout=5_000)
        page.press("#subjectsInput", "Enter")

    # --- Hobbies checkboxes (1=Sports, 2=Reading, 3=Music) ---
    for index in data.get("hobby_indices", []):
        page.click(f"label[for='hobbies-checkbox-{index}']")

    # --- Current address ---
    page.fill("#currentAddress", data["address"])

    # --- State dropdown (React Select with hashed CSS class names) ---
    page.evaluate("document.getElementById('state').scrollIntoView()")
    page.click("#state [class*='control']")
    page.wait_for_selector("#state [class*='menu']", timeout=5_000)
    page.click(f"#state [class*='option']:has-text('{data['state']}')")

    # --- City dropdown ---
    page.wait_for_timeout(300)
    page.click("#city [class*='control']")
    page.wait_for_selector("#city [class*='menu']", timeout=5_000)
    page.click(f"#city [class*='option']:has-text('{data['city']}')")

    # --- Submit (scroll into view first to avoid hidden element issues) ---
    page.evaluate("document.getElementById('submit').scrollIntoView()")
    page.click("#submit")

    # --- Read confirmation modal ---
    try:
        page.wait_for_selector("#example-modal-sizes-title-lg", timeout=8_000)
        confirmation = page.inner_text(".modal-body table") or page.inner_text(".modal-body")
    except PWTimeoutError:
        confirmation = "Confirmation modal did not appear."

    return confirmation.strip()


def demo_form_automation(headless: bool = True) -> None:
    """Fill the DemoQA practice form with sample data and save the result."""
    banner("Form Automation", "demoqa.com — all field types + session export")

    form_data = {
        "first_name":   "Jane",
        "last_name":    "Doe",
        "email":        "jane.doe@example.com",
        "gender_index": 2,          # 1=Male, 2=Female, 3=Other
        "mobile":       "9876543210",
        "dob_day":      "15",
        "dob_month":    "March",
        "dob_year":     "1995",
        "subjects":     ["Maths", "Computer Science"],
        "hobby_indices": [1, 2],    # Sports, Reading
        "address":      "123 Playwright Ave, Test City, TC 00000",
        "state":        "NCR",
        "city":         "Delhi",
    }

    section("Form fields to fill")
    kv("Name",     f"{form_data['first_name']} {form_data['last_name']}")
    kv("Email",    form_data["email"])
    kv("DOB",      f"{form_data['dob_day']} {form_data['dob_month']} {form_data['dob_year']}")
    kv("Subjects", ", ".join(form_data["subjects"]))
    kv("State",    f"{form_data['state']} / {form_data['city']}")

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=headless)
        context = browser.new_context(viewport={"width": 1366, "height": 900})
        page    = context.new_page()

        section("Submitting form")

        total_steps = 7
        step(1, total_steps, "Loading page")
        with Spinner("Navigating to form"):
            page.goto("https://demoqa.com/automation-practice-form", wait_until="networkidle")
            page.evaluate("document.getElementById('fixedban')?.remove()")
            page.evaluate("document.querySelector('footer')?.remove()")
        ok("Page loaded")

        step(2, total_steps, "Filling text fields")
        with Spinner("Name · Email · Mobile"):
            page.fill("#firstName",  form_data["first_name"])
            page.fill("#lastName",   form_data["last_name"])
            page.fill("#userEmail",  form_data["email"])
            page.fill("#userNumber", form_data["mobile"])
            page.click(f"label[for='gender-radio-{form_data['gender_index']}']")
        ok("Text fields filled")

        step(3, total_steps, "Setting date of birth")
        with Spinner(f"Date picker → {form_data['dob_day']} {form_data['dob_month']} {form_data['dob_year']}"):
            _set_date_picker(page, form_data["dob_day"], form_data["dob_month"], form_data["dob_year"])
        ok("Date of birth set")

        step(4, total_steps, "Subjects autocomplete")
        with Spinner("Adding subjects"):
            for subject in form_data.get("subjects", []):
                page.fill("#subjectsInput", subject)
                page.wait_for_selector(".subjects-auto-complete__option", timeout=5_000)
                page.press("#subjectsInput", "Enter")
        ok(f"Subjects: {', '.join(form_data['subjects'])}")

        step(5, total_steps, "Hobbies checkboxes")
        with Spinner("Checking hobbies"):
            for index in form_data.get("hobby_indices", []):
                page.click(f"label[for='hobbies-checkbox-{index}']")
            page.fill("#currentAddress", form_data["address"])
        ok("Hobbies and address filled")

        step(6, total_steps, "State / City dropdowns")
        with Spinner("Selecting state and city"):
            page.evaluate("document.getElementById('state').scrollIntoView()")
            page.click("#state [class*='control']")
            page.wait_for_selector("#state [class*='menu']", timeout=5_000)
            page.click(f"#state [class*='option']:has-text('{form_data['state']}')")
            page.wait_for_timeout(300)
            page.click("#city [class*='control']")
            page.wait_for_selector("#city [class*='menu']", timeout=5_000)
            page.click(f"#city [class*='option']:has-text('{form_data['city']}')")
        ok(f"State: {form_data['state']} · City: {form_data['city']}")

        step(7, total_steps, "Submitting and reading confirmation")
        with Spinner("Submitting form"):
            page.evaluate("document.getElementById('submit').scrollIntoView()")
            page.click("#submit")
            try:
                page.wait_for_selector("#example-modal-sizes-title-lg", timeout=8_000)
                confirmation = page.inner_text(".modal-body table") or page.inner_text(".modal-body")
            except PWTimeoutError:
                confirmation = "Confirmation modal did not appear."

        ok("Form submitted successfully")

        screenshot_path = OUTPUT_DIR / "form_confirmation.png"
        with Spinner("Saving confirmation screenshot"):
            page.screenshot(path=str(screenshot_path))
        ok(f"Screenshot → {screenshot_path}")

        browser.close()

    section("Confirmation from site")
    for line in confirmation.strip().splitlines():
        if line.strip():
            parts = line.split("\t")
            if len(parts) == 2:
                kv(parts[0].strip(), parts[1].strip())
            else:
                info(line.strip())

    result = FormSubmissionResult(
        submitted_at=datetime.now().isoformat(),
        name=f"{form_data['first_name']} {form_data['last_name']}",
        email=form_data["email"],
        gender="Female",
        mobile=form_data["mobile"],
        subjects=form_data["subjects"],
        hobbies=["Sports", "Reading"],
        address=form_data["address"],
        state=form_data["state"],
        city=form_data["city"],
        confirmation_text=confirmation,
        screenshot=str(screenshot_path),
    )

    section("Saving result")
    export_json([asdict(result)], "form_submission_result.json")

    result_box([
        ("Name",        result.name),
        ("Email",       result.email),
        ("DOB",         f"{form_data['dob_day']} {form_data['dob_month']} {form_data['dob_year']}"),
        ("State/City",  f"{result.state} / {result.city}"),
        ("Screenshot",  str(screenshot_path)),
        ("JSON export", "output/form_submission_result.json"),
    ], title="Form Submission Summary")

    done("Form automation complete.")


def demo_multi_submit(records: list[dict], headless: bool = True) -> list[dict]:
    """
    Submit the form multiple times from a list of records.
    Useful for bulk form-filling automation tasks.
    Returns a list of submission results.
    """
    results = []

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=headless)

        for i, record in enumerate(records):
            context = browser.new_context(viewport={"width": 1366, "height": 900})
            page    = context.new_page()

            step(i + 1, len(records), f"{record.get('first_name')} {record.get('last_name')}")
            try:
                with Spinner("Submitting"):
                    confirmation = fill_practice_form(page, record)
                results.append({"record": record, "status": "success", "confirmation": confirmation})
                ok("Success")
            except Exception as e:
                results.append({"record": record, "status": "error", "error": str(e)})
                warn(f"Error: {e}")
            finally:
                context.close()

        browser.close()

    export_json(results, "multi_submit_results.json")
    return results


if __name__ == "__main__":
    demo_form_automation(headless=True)
