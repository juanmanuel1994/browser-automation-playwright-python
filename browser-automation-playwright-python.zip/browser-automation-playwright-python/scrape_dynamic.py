"""
Scraper for JavaScript-rendered (SPA/dynamic) pages using Playwright.
Waits for network activity to settle and specific DOM elements to appear
before extracting data — handles React, Vue, Angular, and similar frameworks.
"""

import os
import json
from pathlib import Path
from dataclasses import dataclass, asdict
from typing import Optional
from dotenv import load_dotenv
from playwright.sync_api import sync_playwright, Page, TimeoutError as PWTimeoutError
from ui import banner, section, ok, info, warn, kv, result_box, done, Spinner, progress_bar

load_dotenv()

OUTPUT_DIR = Path(os.getenv("OUTPUT_DIR", "output"))
OUTPUT_DIR.mkdir(exist_ok=True)


@dataclass
class ScrapedItem:
    title: str
    url: str
    description: str
    extra: Optional[str] = None


def wait_for_dynamic_content(page: Page, selector: str, timeout: int = 20_000) -> bool:
    """
    Wait for the page's JS to finish rendering and a key selector to appear.
    Returns True if the element appeared within the timeout.
    """
    try:
        page.wait_for_load_state("networkidle", timeout=timeout)
        page.wait_for_selector(selector, timeout=timeout)
        return True
    except PWTimeoutError:
        warn(f"Timeout waiting for selector '{selector}'")
        return False


def scroll_to_load_lazy(page: Page, scroll_pause: int = 800, max_scrolls: int = 5) -> None:
    """
    Scroll down the page in steps to trigger lazy-loaded content.
    Stops early if the page height stops growing.
    """
    previous_height = 0
    for i in range(max_scrolls):
        page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
        page.wait_for_timeout(scroll_pause)
        current_height = page.evaluate("document.body.scrollHeight")
        progress_bar(i + 1, max_scrolls, "scrolling for lazy content")
        if current_height == previous_height:
            break
        previous_height = current_height


def extract_items_generic(page: Page) -> list[ScrapedItem]:
    """
    Generic extraction: grab all <a> tags with meaningful text as items.
    Override this function with site-specific selectors for real projects.
    """
    items = page.evaluate("""
        () => {
            return Array.from(document.querySelectorAll('a[href]'))
                .filter(el => el.innerText.trim().length > 5)
                .slice(0, 30)
                .map(el => ({
                    title: el.innerText.trim(),
                    url: el.href,
                    description: el.closest('article, .card, .item, li')?.innerText?.trim() || '',
                    extra: el.getAttribute('data-id') || null
                }));
        }
    """)
    return [ScrapedItem(**item) for item in items]


def scrape_page(url: str, wait_selector: str = "body", headless: bool = True) -> list[ScrapedItem]:
    """
    Open a JS-rendered URL, wait for content, scroll for lazy loads, then extract items.
    """
    results: list[ScrapedItem] = []

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=headless)
        context = browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124 Safari/537.36"
        )
        page = context.new_page()

        info(f"Navigating to: {url}")
        with Spinner("Waiting for JS to render"):
            page.goto(url, wait_until="domcontentloaded")
            ready = wait_for_dynamic_content(page, wait_selector)

        if not ready:
            warn("Page may not be fully loaded. Proceeding anyway.")
        else:
            ok("Dynamic content detected")

        section("Scrolling for lazy-loaded content")
        scroll_to_load_lazy(page)

        with Spinner("Extracting items from DOM"):
            results = extract_items_generic(page)

        ok(f"Extracted {len(results)} items")
        browser.close()

    return results


def save_results(items: list[ScrapedItem], filename: str = "scraped_data.json") -> Path:
    """Save scraped items as a JSON file in the output directory."""
    path = OUTPUT_DIR / filename
    with open(path, "w", encoding="utf-8") as f:
        json.dump([asdict(item) for item in items], f, indent=2, ensure_ascii=False)
    ok(f"Saved {len(items)} items → {path}")
    return path


def demo_scrape() -> None:
    """
    Demo: scrape a public JS-rendered site (Hacker News SPA mirror).
    Replace URL and selector with your target.
    """
    banner("Dynamic Scraper", "JS-rendered page scraping with Playwright")

    url = os.getenv("SCRAPE_URL", "https://news.ycombinator.com/")

    section("Scraping")
    items = scrape_page(url, wait_selector=".titleline", headless=True)
    path  = save_results(items, "scraped_data.json")

    section("Sample items")
    for item in items[:3]:
        kv(item.title[:30], item.url[:55])

    result_box([
        ("Target URL",  url),
        ("Items found", str(len(items))),
        ("Output file", str(path)),
    ], title="Scrape Summary")

    done("Dynamic scrape complete.")


if __name__ == "__main__":
    demo_scrape()
