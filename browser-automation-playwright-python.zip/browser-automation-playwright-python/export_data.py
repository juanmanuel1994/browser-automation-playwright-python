"""
CSV and JSON export utilities for scraped data.
Works with any list of dictionaries; pairs naturally with scrape_dynamic.py.
"""

import csv
import json
import os
from pathlib import Path
from datetime import datetime
from typing import Any
from dotenv import load_dotenv
from ui import banner, section, ok, info, kv, result_box, done, Spinner

load_dotenv()

OUTPUT_DIR = Path(os.getenv("OUTPUT_DIR", "output"))
OUTPUT_DIR.mkdir(exist_ok=True)


def _timestamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def export_json(data: list[dict[str, Any]], filename: str | None = None, indent: int = 2) -> Path:
    """
    Write a list of dicts to a pretty-printed JSON file.
    Returns the output path.
    """
    filename = filename or f"export_{_timestamp()}.json"
    path = OUTPUT_DIR / filename

    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=indent, ensure_ascii=False)

    ok(f"JSON export: {path}  ({len(data)} records)")
    return path


def export_csv(data: list[dict[str, Any]], filename: str | None = None) -> Path:
    """
    Write a list of dicts to a CSV file.
    Column order follows the keys of the first record.
    Returns the output path.
    """
    if not data:
        raise ValueError("Cannot export empty dataset to CSV.")

    filename = filename or f"export_{_timestamp()}.csv"
    path = OUTPUT_DIR / filename
    fieldnames = list(data[0].keys())

    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(data)

    ok(f"CSV export: {path}  ({len(data)} rows, {len(fieldnames)} columns)")
    return path


def load_json(path: str | Path) -> list[dict[str, Any]]:
    """Load a previously saved JSON export back into memory."""
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def load_csv(path: str | Path) -> list[dict[str, Any]]:
    """Load a previously saved CSV export back into memory as a list of dicts."""
    with open(path, "r", encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def merge_exports(*paths: str | Path, output_filename: str | None = None) -> Path:
    """
    Merge multiple JSON export files into one deduplicated JSON file.
    Deduplication is based on the 'url' field when present, otherwise no dedup.
    """
    merged: list[dict] = []
    seen_urls: set[str] = set()

    for path in paths:
        records = load_json(path)
        for record in records:
            url = record.get("url", "")
            if url and url in seen_urls:
                continue
            seen_urls.add(url)
            merged.append(record)

    output_filename = output_filename or f"merged_{_timestamp()}.json"
    return export_json(merged, output_filename)


def demo_export() -> None:
    """Demo: create sample data and export it to both formats."""
    banner("Export Data", "CSV & JSON export / import utilities")

    sample_data = [
        {
            "title": "Playwright Automation Guide",
            "url": "https://playwright.dev/python/",
            "description": "Official Python docs for Playwright",
            "price": None,
            "rating": 5,
        },
        {
            "title": "Automate the Boring Stuff",
            "url": "https://automatetheboringstuff.com/",
            "description": "Python automation book — free online",
            "price": 0.00,
            "rating": 5,
        },
        {
            "title": "RealPython Scraping Tutorial",
            "url": "https://realpython.com/python-web-scraping-practical-introduction/",
            "description": "Practical scraping tutorial with Python",
            "price": None,
            "rating": 4,
        },
    ]

    section("Exporting sample data")
    with Spinner("Writing files to disk"):
        json_path = export_json(sample_data, "demo_export.json")
        csv_path  = export_csv(sample_data, "demo_export.csv")

    section("Round-trip verification")
    reloaded_json = load_json(json_path)
    reloaded_csv  = load_csv(csv_path)
    ok(f"JSON round-trip: {len(reloaded_json)} records")
    ok(f"CSV round-trip:  {len(reloaded_csv)} records")

    result_box([
        ("JSON file", str(json_path)),
        ("CSV file",  str(csv_path)),
        ("Records",   str(len(sample_data))),
        ("Columns",   str(len(sample_data[0]))),
    ], title="Export Summary")

    done("Export demo complete.")


if __name__ == "__main__":
    demo_export()
