"""
Terminal UI helpers: colors, spinner, banners, progress bar.
ASCII-only characters for full Windows CMD compatibility.
ANSI colors enabled via Windows API when needed.
"""

import sys
import time
import threading
import shutil
import ctypes
import io
from typing import Any


# ── Enable ANSI escape codes on Windows CMD ──────────────────────────────────
def _enable_ansi() -> None:
    try:
        kernel32 = ctypes.windll.kernel32
        # ENABLE_PROCESSED_OUTPUT | ENABLE_WRAP_AT_EOL_OUTPUT | ENABLE_VIRTUAL_TERMINAL_PROCESSING
        kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 0x0001 | 0x0002 | 0x0004)
    except Exception:
        pass

_enable_ansi()

# Force UTF-8 only when the environment truly supports it; otherwise stay ASCII
def _setup_stdout() -> None:
    try:
        if hasattr(sys.stdout, "reconfigure"):
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        elif hasattr(sys.stdout, "buffer"):
            sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    except Exception:
        pass

_setup_stdout()


# ── ANSI color codes ──────────────────────────────────────────────────────────
class C:
    RESET   = "\033[0m"
    BOLD    = "\033[1m"
    DIM     = "\033[2m"
    RED     = "\033[91m"
    GREEN   = "\033[92m"
    YELLOW  = "\033[93m"
    BLUE    = "\033[94m"
    MAGENTA = "\033[95m"
    CYAN    = "\033[96m"
    WHITE   = "\033[97m"

    @staticmethod
    def strip(text: str) -> str:
        import re
        return re.sub(r"\033\[[0-9;]*m", "", text)


# ── Spinner (ASCII frames, no Unicode) ───────────────────────────────────────
class Spinner:
    FRAMES = ["|", "/", "-", "\\"]

    def __init__(self, label: str, color: str = C.CYAN):
        self.label = label
        self.color = color
        self._stop  = threading.Event()
        self._thread: threading.Thread | None = None

    def _spin(self) -> None:
        idx = 0
        while not self._stop.is_set():
            frame = self.FRAMES[idx % len(self.FRAMES)]
            sys.stdout.write(f"\r  {self.color}{frame}{C.RESET}  {self.label}  ")
            sys.stdout.flush()
            time.sleep(0.1)
            idx += 1

    def __enter__(self):
        self._stop.clear()
        self._thread = threading.Thread(target=self._spin, daemon=True)
        self._thread.start()
        return self

    def __exit__(self, *_):
        self._stop.set()
        if self._thread:
            self._thread.join()
        sys.stdout.write("\r" + " " * 60 + "\r")
        sys.stdout.flush()


# ── Progress bar (ASCII only) ─────────────────────────────────────────────────
def progress_bar(current: int, total: int, label: str = "", width: int = 28) -> None:
    filled  = int(width * current / total) if total else 0
    bar     = f"{C.CYAN}{'#' * filled}{C.DIM}{'.' * (width - filled)}{C.RESET}"
    pct     = f"{C.BOLD}{100 * current // total:3d}%{C.RESET}"
    count   = f"{C.DIM}({current}/{total}){C.RESET}"
    sys.stdout.write(f"\r  [{bar}] {pct} {count}  {label}  ")
    sys.stdout.flush()
    if current >= total:
        sys.stdout.write("\n")
        sys.stdout.flush()


# ── Print helpers ─────────────────────────────────────────────────────────────
def ok(msg: str)   -> None: print(f"  {C.GREEN}[OK]{C.RESET}  {msg}")
def info(msg: str) -> None: print(f"  {C.CYAN}[>>]{C.RESET}  {msg}")
def warn(msg: str) -> None: print(f"  {C.YELLOW}[!!]{C.RESET}  {msg}")
def err(msg: str)  -> None: print(f"  {C.RED}[XX]{C.RESET}  {msg}")

def step(n: int, total: int, msg: str) -> None:
    print(f"  {C.MAGENTA}[{n}/{total}]{C.RESET}  {msg}")

def kv(key: str, value: Any, key_width: int = 18) -> None:
    print(f"  {C.DIM}{key:<{key_width}}{C.RESET}  {C.WHITE}{value}{C.RESET}")

def section(title: str) -> None:
    width = min(shutil.get_terminal_size().columns - 2, 58)
    print()
    print(f"  {C.BOLD}{C.CYAN}{title}{C.RESET}")
    print(f"  {C.DIM}{'-' * width}{C.RESET}")


# ── Banner ────────────────────────────────────────────────────────────────────
def banner(title: str, subtitle: str = "") -> None:
    width  = min(shutil.get_terminal_size().columns - 2, 60)
    border = f"{C.CYAN}{'=' * width}{C.RESET}"
    print()
    print(f"  {border}")
    t_pad = (width - len(title)) // 2
    print(f"  {C.CYAN}|{C.RESET}" + " " * (t_pad - 1) + f"{C.BOLD}{C.WHITE}{title}{C.RESET}" + " " * (width - t_pad - len(title) - 1) + f"{C.CYAN}|{C.RESET}")
    if subtitle:
        s_pad = (width - len(subtitle)) // 2
        print(f"  {C.CYAN}|{C.RESET}" + " " * (s_pad - 1) + f"{C.DIM}{subtitle}{C.RESET}" + " " * (width - s_pad - len(subtitle) - 1) + f"{C.CYAN}|{C.RESET}")
    print(f"  {border}")
    print()


# ── Result box ────────────────────────────────────────────────────────────────
def result_box(rows: list[tuple[str, str]], title: str = "Result") -> None:
    width = min(shutil.get_terminal_size().columns - 4, 58)
    inner = width - 2
    print()
    print(f"  {C.GREEN}+{'-' * inner}+{C.RESET}")
    # title row
    t = f" {title}"
    print(f"  {C.GREEN}|{C.RESET}{C.BOLD}{t:<{inner}}{C.RESET}{C.GREEN}|{C.RESET}")
    print(f"  {C.GREEN}+{'-' * inner}+{C.RESET}")
    for key, val in rows:
        val_str  = str(val)
        max_val  = inner - 21
        if len(val_str) > max_val:
            val_str = val_str[:max_val - 2] + ".."
        line = f" {C.DIM}{key:<18}{C.RESET}  {C.WHITE}{val_str}{C.RESET}"
        visible = f" {key:<18}  {val_str}"
        pad  = inner - len(visible)
        print(f"  {C.GREEN}|{C.RESET}{line}{' ' * max(pad, 0)}{C.GREEN}|{C.RESET}")
    print(f"  {C.GREEN}+{'-' * inner}+{C.RESET}")
    print()


def done(msg: str = "All done!") -> None:
    print()
    print(f"  {C.BOLD}{C.GREEN}[DONE]  {msg}{C.RESET}")
    print()
