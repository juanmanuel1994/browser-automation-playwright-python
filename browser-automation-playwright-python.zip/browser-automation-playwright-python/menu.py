"""
Main interactive menu for the Playwright automation toolkit.
Run:  python menu.py   (or double-click run.bat)
"""

import sys
import os
import time
import shutil
import subprocess
from pathlib import Path

# Set UTF-8 code page on Windows CMD so colors and box chars render correctly
if os.name == "nt":
    os.system("chcp 65001 >nul 2>&1")

# Ensure the project root is on sys.path
ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT))

from ui import C, _enable_ansi, banner, section, ok, info, warn, err, kv, done, Spinner

_enable_ansi()

# ── Menu entries ──────────────────────────────────────────────────────────────
MENU_ITEMS = [
    ("1", "Export Data",         "CSV & JSON export / import utilities",          "export_data.py"),
    ("2", "Login Automation",    "Auto-login + session save & reuse",             "login_automation.py"),
    ("3", "Dynamic Scraper",     "Scrape JS-rendered pages (Hacker News demo)",   "scrape_dynamic.py"),
    ("4", "Screenshot Capture",  "Full-page, viewport, element, mobile, batch",   "screenshot_capture.py"),
    ("5", "E-commerce Scraper",  "Scrape books.toscrape.com -> CSV + JSON",       "examples/ecommerce_scraper.py"),
    ("6", "Form Automation",     "Fill & submit demoqa.com practice form",        "examples/form_automation.py"),
    ("7", "Run ALL scripts",     "Execute every script in sequence",              None),
    ("0", "Exit",                "Quit the toolkit",                              None),
]

# Color per option number
COLORS = {
    "1": C.CYAN,
    "2": C.GREEN,
    "3": C.YELLOW,
    "4": C.MAGENTA,
    "5": C.BLUE,
    "6": C.CYAN,
    "7": C.WHITE,
    "0": C.RED,
}


# ── Drawing helpers ───────────────────────────────────────────────────────────
def _clear() -> None:
    os.system("cls" if os.name == "nt" else "clear")


def _width() -> int:
    return min(shutil.get_terminal_size().columns, 64)


def _center(text: str, width: int, fill: str = " ") -> str:
    """Center plain text (no ANSI) within width."""
    stripped = C.strip(text)
    pad = max(width - len(stripped), 0)
    left  = pad // 2
    right = pad - left
    return fill * left + text + fill * right


def draw_header() -> None:
    w = _width()
    border = C.CYAN + "=" * w + C.RESET

    title    = "PLAYWRIGHT AUTOMATION TOOLKIT"
    subtitle = "Python  |  Playwright  |  Browser Automation"

    print()
    print(border)
    print(C.CYAN + "|" + C.RESET + _center(f"{C.BOLD}{C.WHITE}{title}{C.RESET}", w - 2) + C.CYAN + "|" + C.RESET)
    print(C.CYAN + "|" + C.RESET + _center(f"{C.DIM}{subtitle}{C.RESET}",        w - 2) + C.CYAN + "|" + C.RESET)
    print(border)
    print()


def draw_menu() -> None:
    w     = _width()
    inner = w - 4          # inside the box borders

    print(f"  {C.CYAN}+{'-' * inner}+{C.RESET}")
    label = " SELECT A TASK"
    print(f"  {C.CYAN}|{C.RESET}{C.BOLD}{label:<{inner}}{C.RESET}{C.CYAN}|{C.RESET}")
    print(f"  {C.CYAN}+{'-' * inner}+{C.RESET}")

    for key, title, desc, _ in MENU_ITEMS:
        color = COLORS.get(key, C.WHITE)
        # Key badge
        badge = f"{color}[{key}]{C.RESET}"
        # Title + dim description
        body  = f" {C.BOLD}{color}{title:<22}{C.RESET}  {C.DIM}{desc}{C.RESET}"
        # Measure visible length for padding
        visible_len = 1 + len(f"[{key}]") + 1 + len(title) + 24 + len(desc)
        pad = max(inner - visible_len - 1, 0)

        print(f"  {C.CYAN}|{C.RESET}  {badge}{body}{' ' * pad}{C.CYAN}|{C.RESET}")

    print(f"  {C.CYAN}+{'-' * inner}+{C.RESET}")
    print()


def draw_footer() -> None:
    w = _width()
    print(f"  {C.DIM}{'=' * w}{C.RESET}")
    print(f"  {C.DIM}Output files are saved to  ->  output/{C.RESET}")
    print(f"  {C.DIM}{'=' * w}{C.RESET}")
    print()


# ── Script runner ─────────────────────────────────────────────────────────────
def run_script(script_path: str, title: str) -> bool:
    """Run a script as a subprocess and stream its output."""
    _clear()
    w = _width()
    print()
    print(f"  {C.CYAN}{'=' * w}{C.RESET}")
    print(f"  {C.CYAN}|{C.RESET}" + _center(f"{C.BOLD}{C.WHITE}RUNNING: {title}{C.RESET}", w - 2) + f"{C.CYAN}|{C.RESET}")
    print(f"  {C.CYAN}{'=' * w}{C.RESET}")
    print()

    full_path = ROOT / script_path
    cmd = [sys.executable, str(full_path)]

    try:
        result = subprocess.run(
            cmd,
            cwd=str(ROOT),
            env={**os.environ, "PYTHONIOENCODING": "utf-8"},
        )
        success = result.returncode == 0
    except Exception as e:
        err(f"Failed to run {script_path}: {e}")
        success = False

    print()
    if success:
        print(f"  {C.GREEN}{'=' * w}{C.RESET}")
        print(f"  {C.GREEN}|{C.RESET}" + _center(f"{C.BOLD}{C.GREEN}FINISHED: {title}{C.RESET}", w - 2) + f"{C.GREEN}|{C.RESET}")
        print(f"  {C.GREEN}{'=' * w}{C.RESET}")
    else:
        print(f"  {C.RED}{'=' * w}{C.RESET}")
        print(f"  {C.RED}|{C.RESET}" + _center(f"{C.BOLD}{C.RED}ERROR in: {title}{C.RESET}", w - 2) + f"{C.RED}|{C.RESET}")
        print(f"  {C.RED}{'=' * w}{C.RESET}")

    print()
    input(f"  {C.DIM}Press ENTER to return to menu...{C.RESET}  ")
    return success


def run_all() -> None:
    """Run every script in sequence."""
    _clear()
    scripts = [(title, path) for _, title, _, path in MENU_ITEMS if path is not None]
    w = _width()
    print()
    print(f"  {C.WHITE}{'=' * w}{C.RESET}")
    print(f"  {C.WHITE}|{C.RESET}" + _center(f"{C.BOLD}{C.WHITE}RUNNING ALL {len(scripts)} SCRIPTS{C.RESET}", w - 2) + f"{C.WHITE}|{C.RESET}")
    print(f"  {C.WHITE}{'=' * w}{C.RESET}")
    print()

    results = []
    for i, (title, path) in enumerate(scripts, 1):
        print(f"  {C.MAGENTA}[{i}/{len(scripts)}]{C.RESET}  {C.BOLD}{title}{C.RESET}")
        full_path = ROOT / path
        try:
            result = subprocess.run(
                [sys.executable, str(full_path)],
                cwd=str(ROOT),
                env={**os.environ, "PYTHONIOENCODING": "utf-8"},
            )
            success = result.returncode == 0
        except Exception as e:
            err(str(e))
            success = False

        status = f"{C.GREEN}OK{C.RESET}" if success else f"{C.RED}FAILED{C.RESET}"
        print(f"         Status: {status}")
        print()
        results.append((title, success))

    # Summary table
    print(f"  {C.BOLD}{'=' * w}{C.RESET}")
    print(f"  {C.BOLD}  SUMMARY{C.RESET}")
    print(f"  {'-' * w}")
    for title, success in results:
        icon  = f"{C.GREEN}[OK]{C.RESET}    " if success else f"{C.RED}[FAIL]{C.RESET}  "
        print(f"  {icon} {title}")
    print(f"  {'-' * w}")
    passed = sum(1 for _, s in results if s)
    color  = C.GREEN if passed == len(results) else C.YELLOW
    print(f"  {color}{C.BOLD}  {passed}/{len(results)} scripts completed successfully.{C.RESET}")
    print()
    input(f"  {C.DIM}Press ENTER to return to menu...{C.RESET}  ")


# ── Main loop ─────────────────────────────────────────────────────────────────
def main() -> None:
    while True:
        _clear()
        draw_header()
        draw_menu()
        draw_footer()

        choice = input(f"  {C.BOLD}{C.WHITE}Enter option: {C.RESET}").strip()
        print()

        if choice == "0":
            _clear()
            print()
            print(f"  {C.CYAN}Goodbye! Happy automating.{C.RESET}")
            print()
            sys.exit(0)

        elif choice == "7":
            run_all()

        else:
            match = next(((t, p) for k, t, _, p in MENU_ITEMS if k == choice and p), None)
            if match:
                title, path = match
                run_script(path, title)
            else:
                warn("Invalid option. Press ENTER and try again.")
                input()


if __name__ == "__main__":
    main()
