"""
Automatic login script using Playwright.
Demonstrates form filling, submission, and session persistence via storage state.
"""

import os
from pathlib import Path
from dotenv import load_dotenv
from playwright.sync_api import sync_playwright, Page, BrowserContext
from ui import banner, section, ok, info, warn, kv, result_box, done, Spinner

load_dotenv()

OUTPUT_DIR = Path(os.getenv("OUTPUT_DIR", "output"))
OUTPUT_DIR.mkdir(exist_ok=True)

SESSION_FILE = OUTPUT_DIR / "session.json"


def _fill_first(page: Page, selectors: list[str], value: str) -> None:
    """Try each selector in order and fill the first one that exists on the page."""
    for sel in selectors:
        if page.query_selector(sel):
            page.fill(sel, value)
            return
    raise ValueError(f"None of the selectors found on page: {selectors}")


def _click_first(page: Page, selectors: list[str]) -> None:
    """Click the first matching element from the selector list."""
    for sel in selectors:
        if page.query_selector(sel):
            page.click(sel)
            return
    raise ValueError(f"None of the selectors found on page: {selectors}")


def login(page: Page, url: str, username: str, password: str) -> bool:
    """
    Navigate to a login page, fill credentials, and submit the form.
    Returns True if login succeeded (redirected away from login URL).
    """
    page.goto(url, wait_until="networkidle")

    # Fill username — adjust selectors to match your target site
    _fill_first(page, ['input[name="username"]', 'input[name="email"]', "#username", "#email"], username)
    _fill_first(page, ['input[name="password"]', 'input[type="password"]'], password)

    # Click submit and wait for navigation
    with page.expect_navigation(wait_until="networkidle", timeout=15_000):
        _click_first(page, [
            'button[type="submit"]',
            'input[type="submit"]',
            'button:has-text("Log in")',
            'button:has-text("Sign in")',
            'button:has-text("Submit")',
        ])

    current_url = page.url
    success = url not in current_url
    return success


def save_session(context: BrowserContext, path: Path = SESSION_FILE) -> None:
    """Persist browser cookies and storage state to a JSON file for reuse."""
    context.storage_state(path=str(path))
    ok(f"Session saved → {path}")


def load_session(playwright, headless: bool = True) -> tuple:
    """
    Launch a browser with a previously saved session.
    Returns (browser, context, page) or raises FileNotFoundError.
    """
    if not SESSION_FILE.exists():
        raise FileNotFoundError(f"No session file found at {SESSION_FILE}. Run login first.")

    browser = playwright.chromium.launch(headless=headless)
    context = browser.new_context(storage_state=str(SESSION_FILE))
    page = context.new_page()
    return browser, context, page


def demo_login(headless: bool = True) -> None:
    """
    Full demo: log in to a site, save session, then reuse it.
    Uses environment variables for credentials.
    """
    banner("Login Automation", "Automatic login + session persistence")

    url      = os.getenv("LOGIN_URL",      "https://practicetestautomation.com/practice-test-login/")
    username = os.getenv("LOGIN_USERNAME", "student")
    password = os.getenv("LOGIN_PASSWORD", "Password123")

    section("Step 1 — Logging in")
    info(f"Target: {url}")
    info(f"User:   {username}")

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=headless)
        context = browser.new_context()
        page    = context.new_page()

        with Spinner("Navigating and submitting login form"):
            success = login(page, url, username, password)

        if success:
            ok(f"Login successful → {page.url}")
            save_session(context)

            screenshot_path = OUTPUT_DIR / "post_login.png"
            with Spinner("Capturing post-login screenshot"):
                page.screenshot(path=str(screenshot_path), full_page=True)
            ok(f"Screenshot saved → {screenshot_path}")
        else:
            warn("Login may have failed — still on login page.")

        browser.close()

        section("Step 2 — Reusing saved session")
        if success and SESSION_FILE.exists():
            with Spinner("Launching browser with saved session"):
                browser2, context2, page2 = load_session(p, headless=headless)
                page2.goto("https://practicetestautomation.com/practice-test-login/")

            ok(f"Page loaded with saved session: {page2.url}")
            browser2.close()

    result_box([
        ("Login URL",    url),
        ("Username",     username),
        ("Status",       "Success" if success else "Failed"),
        ("Session file", str(SESSION_FILE)),
        ("Screenshot",   str(OUTPUT_DIR / "post_login.png")),
    ], title="Login Summary")

    done("Login automation complete.")


if __name__ == "__main__":
    demo_login(headless=True)
