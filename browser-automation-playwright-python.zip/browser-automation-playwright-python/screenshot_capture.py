"""
Screenshot capture utilities using Playwright.
Supports full-page, viewport-only, element-specific, and multi-URL batch screenshots.
"""

import os
from pathlib import Path
from datetime import datetime
from dotenv import load_dotenv
from playwright.sync_api import sync_playwright, Page
from ui import banner, section, ok, info, warn, err, kv, result_box, done, Spinner, progress_bar

load_dotenv()

OUTPUT_DIR = Path(os.getenv("OUTPUT_DIR", "output"))
OUTPUT_DIR.mkdir(exist_ok=True)


def _timestamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def screenshot_full_page(url: str, filename: str | None = None, headless: bool = True) -> Path:
    """Capture a full-page screenshot (scrolls and stitches the entire page)."""
    filename = filename or f"full_{_timestamp()}.png"
    output_path = OUTPUT_DIR / filename

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=headless)
        page = browser.new_page(viewport={"width": 1280, "height": 900})
        page.goto(url, wait_until="networkidle")
        page.screenshot(path=str(output_path), full_page=True)
        browser.close()

    ok(f"Full-page PNG → {output_path}")
    return output_path


def screenshot_viewport(url: str, filename: str | None = None, headless: bool = True) -> Path:
    """Capture only the visible viewport area."""
    filename = filename or f"viewport_{_timestamp()}.png"
    output_path = OUTPUT_DIR / filename

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=headless)
        page = browser.new_page(viewport={"width": 1280, "height": 900})
        page.goto(url, wait_until="networkidle")
        page.screenshot(path=str(output_path), full_page=False)
        browser.close()

    ok(f"Viewport PNG  → {output_path}")
    return output_path


def screenshot_element(url: str, selector: str, filename: str | None = None, headless: bool = True) -> Path:
    """
    Capture a screenshot of a specific DOM element identified by a CSS selector.
    Useful for isolating charts, cards, banners, etc.
    """
    filename = filename or f"element_{_timestamp()}.png"
    output_path = OUTPUT_DIR / filename

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=headless)
        page = browser.new_page(viewport={"width": 1280, "height": 900})
        page.goto(url, wait_until="networkidle")
        element = page.query_selector(selector)
        if element is None:
            raise ValueError(f"Selector '{selector}' not found on {url}")
        element.screenshot(path=str(output_path))
        browser.close()

    ok(f"Element PNG   → {output_path}  (selector: {selector})")
    return output_path


def screenshot_mobile(url: str, filename: str | None = None, headless: bool = True) -> Path:
    """Capture a screenshot emulating an iPhone 13 screen size and user agent."""
    filename = filename or f"mobile_{_timestamp()}.png"
    output_path = OUTPUT_DIR / filename

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=headless)
        iphone = p.devices["iPhone 13"]
        context = browser.new_context(**iphone)
        page = context.new_page()
        page.goto(url, wait_until="networkidle")
        page.screenshot(path=str(output_path), full_page=True)
        browser.close()

    ok(f"Mobile PNG    → {output_path}  (iPhone 13)")
    return output_path


def screenshot_batch(urls: list[str], headless: bool = True) -> list[Path]:
    """
    Capture full-page screenshots for a list of URLs in a single browser session.
    More efficient than opening a new browser per URL.
    """
    paths: list[Path] = []

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=headless)
        context = browser.new_context(viewport={"width": 1280, "height": 900})

        for i, url in enumerate(urls):
            page = context.new_page()
            try:
                page.goto(url, wait_until="networkidle", timeout=20_000)
                filename = f"batch_{i+1:03d}_{_timestamp()}.png"
                output_path = OUTPUT_DIR / filename
                page.screenshot(path=str(output_path), full_page=True)
                paths.append(output_path)
                progress_bar(i + 1, len(urls), f"batch {i+1}/{len(urls)}")
            except Exception as e:
                err(f"Failed for {url}: {e}")
            finally:
                page.close()

        browser.close()

    return paths


def demo_screenshots() -> None:
    """Demo: capture several screenshot types from a public site."""
    banner("Screenshot Capture", "Full-page · Viewport · Element · Mobile · Batch")

    demo_url = "https://books.toscrape.com/"

    section("Full-page screenshot")
    with Spinner("Rendering full page"):
        screenshot_full_page(demo_url, "demo_full_page.png")

    section("Viewport screenshot")
    with Spinner("Rendering viewport"):
        screenshot_viewport(demo_url, "demo_viewport.png")

    section("Element screenshot")
    with Spinner("Targeting element: article.product_pod"):
        screenshot_element(demo_url, "article.product_pod", "demo_element.png")

    section("Mobile screenshot  (iPhone 13)")
    with Spinner("Emulating iPhone 13"):
        screenshot_mobile(demo_url, "demo_mobile.png")

    section("Batch screenshots")
    batch_urls = [
        "https://books.toscrape.com/catalogue/page-1.html",
        "https://books.toscrape.com/catalogue/page-2.html",
    ]
    info(f"Capturing {len(batch_urls)} URLs")
    paths = screenshot_batch(batch_urls)

    result_box([
        ("Full-page",  "demo_full_page.png"),
        ("Viewport",   "demo_viewport.png"),
        ("Element",    "demo_element.png"),
        ("Mobile",     "demo_mobile.png"),
        ("Batch",      f"{len(paths)} files"),
        ("Output dir", str(OUTPUT_DIR)),
    ], title="Screenshots Summary")

    done("All screenshots captured.")


if __name__ == "__main__":
    demo_screenshots()
